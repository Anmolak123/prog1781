﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A3AnmolakSinghP1
{
    class Program
    {
        static void Main(string[] args)
        {
        again:
            Console.WriteLine("MENU");
            Console.WriteLine("1.display list of even numbers");
            Console.WriteLine("2.display sequence of perfect squares");
            Console.WriteLine("3.exit");
            try
            {
                int choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Enter number of even numbers to be displayed?");
                        int num = int.Parse(Console.ReadLine());
                        for (int i = 0; i < num * 2; i++)
                        {
                            if (i % 2 == 0)
                            {
                                Console.WriteLine(i);
                            }
                        }
                        break;
                    case 2:
                        int q = 1;
                        while (q >= 0)
                        {
                            int qw = q * q;
                            Console.WriteLine(qw);
                            Console.WriteLine("press c for continue , m for main menu");
                            string answer = Console.ReadLine();
                            if (answer == "c")
                            {
                                q++;
                                Console.WriteLine(q);
                            }
                            else
                            {
                                goto again;
                            }
                        }
                        break;
                    case 3: break;

                    default: goto again;
                }
            }
            catch (FormatException z)
            {
                Console.WriteLine("invalid entry");
            }
            finally
            {

            }
        }
    }
}
