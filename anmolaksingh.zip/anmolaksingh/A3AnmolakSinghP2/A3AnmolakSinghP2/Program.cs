﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A3AnmolakSinghP2
{
    class Program
    {
        static void Main(string[] args)
        {
            int fno;
            int sno;
            string operation;
            int res;
            try
            {
            again:
                Console.WriteLine("Enter the first number");
                fno = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the second number");
                sno = Convert.ToInt32(Console.ReadLine());
            num:
                Console.Write("Enter the operation(addition,subraction,multiplication,division) ");
                operation = Console.ReadLine();
                if (operation == "multiplication")
                {
                    res = fno * sno;
                    Console.WriteLine(fno + "x" + sno + "=" + res);
                    goto again;
                }
                else if (operation == "division")
                {
                    res = fno / sno;
                    Console.WriteLine(fno + "/" + sno + "=" + res);
                    goto again;
                }
                else if (operation == "addition")
                {
                    res = fno + sno;
                    Console.WriteLine(fno + "+" + sno + "=" + res);
                    goto again;
                }
                if (operation == "subraction")
                {
                    res = fno - sno;
                    Console.WriteLine(fno + "-" + sno + "=" + res);
                    goto again;
                }
                else
                {
                    Console.WriteLine("Enter a valid operation!!!");
                    goto num;
                }

            }
            catch (ArithmeticException)
            {
                Console.WriteLine("Enter a valid arithmetic expression!!!");
            }
            catch (FormatException)
            {
                Console.WriteLine("Enter a valid format!!!");
            }
        }
    }
}
